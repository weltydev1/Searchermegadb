#include <pthread.h>
#include <jni.h>
#include <dlfcn.h> // Для dlopen, dlsym, dlclose
#include <unistd.h> // Для usleep

// --- Добавлены необходимые стандартные заголовки ---
#include <cstdio>   // Для FILE, fopen, fclose, fgets
#include <cstdlib>  // Для strtoul
#include <cstring>  // Для strstr, strtok
#include <string>   // Для std::string, std::reverse
#include <algorithm> // Для std::reverse

// --- Включено Android логирование ---
#include <android/log.h>

#define LOG_TAG "IL2CPP_MOD"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Простая утилита для поиска базового адреса модуля.
// В реальном сценарии вы бы использовали более надежный метод, возможно, парсинг /proc/self/maps
uintptr_t get_module_base(const char* module_name) {
    FILE *fp;
    uintptr_t base = 0;
    char line[512];
    char *address_str;

    fp = fopen("/proc/self/maps", "r");
    if (fp == NULL) {
        LOGE("Ошибка открытия /proc/self/maps");
        return 0;
    }

    while (fgets(line, sizeof(line), fp) != NULL) {
        // Ищем имя модуля в строке
        if (strstr(line, module_name) != NULL) {
            // Парсим адрес
            address_str = strtok(line, "-");
            if (address_str) { // Проверяем, что strtok вернул что-то
                base = (uintptr_t)strtoul(address_str, NULL, 16);
                break; // Нашли, выходим
            }
        }
    }
    fclose(fp);
    return base;
}

// --- Включаем заголовок для хукинга ---
#include <Substrate/SubstrateHook.h>

// --- Включаем заголовок для чамсов ---
#include "Chams.h"

extern "C" {

/* Время для булевых значений и всего остального */

const char *libName = "libil2cpp.so";
uintptr_t il2cpp_base = 0; // Глобальная переменная для хранения базового адреса библиотеки

// Указатели на функции для игровых функций
// C# сигнатура: private static void SetSpeed_Injected(ref PlayableHandle _unity_self, double value)
// В C++ 'ref PlayableHandle _unity_self' обычно означает указатель на объект (this-pointer)
typedef void (*SetSpeed_Injected_Fn)(void* _unity_self, double value);
// C# сигнатура: public void UpdateWantedLevel(int lvl)
// 'this' указатель для экземпляра объекта, которому принадлежит метод
typedef void (*UpdateWantedLevel_Fn)(void* _this, int lvl);
// C# сигнатура: public void AddMoney(int amount)
// 'this' указатель для экземпляра объекта, которому принадлежит метод
typedef void (*AddMoney_Fn)(void* _this, int amount);

SetSpeed_Injected_Fn SetSpeed_Injected_Ptr = nullptr;
UpdateWantedLevel_Fn UpdateWantedLevel_Ptr = nullptr;
AddMoney_Fn AddMoney_Ptr = nullptr;

// Заполнители для указателей 'this' на игровые объекты.
// В реальном сценарии их нужно найти путем сканирования памяти или другими специфичными для игры способами.
// Например, это может быть указатель 'this' на объект игрока или игровой менеджер.
void* g_player_instance = nullptr; // Замените на реальный адрес экземпляра игрока
void* g_game_manager_instance = nullptr; // Замените на реальный адрес экземпляра игрового менеджера

// Глобальные переменные для состояния чамсов (для UI)
bool wireframe = false;
bool glow = false;
bool shading = false;
bool outline = false;
bool rainbow = false;

// Вспомогательная функция для конвертации jstring в std::string (если понадобится)
std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";
    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));
    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);
    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);
    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

JNIEXPORT jobjectArray JNICALL Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) {
	jobjectArray ret;
	// Формат: тип_id_параметр1_параметр2_Название
	// page_text_icon
	// switch_featureid_text
	// slider_featureid_min_max_Название
	const char *features[] = {
	"page_Visuals_visuals.png",
	"page_Weapons_weapon.png",
	"page_Config_config.png",
	"switch_1_0_Test",
	"slider_2_0_100_1000_Sensitivity",
	"slider_3_0_100_0_PlayerSpeed", // Новая функция: Скорость игрока (от 0 до 100, значение double)
	"slider_4_0_5_0_WantedLevel",   // Новая функция: Уровень розыска (от 0 до 5, значение int)
	"switch_5_0_AddMoney",            // Новая функция: Добавить деньги (кнопка, фиксированная сумма)
    // --- Функции чамсов ---
    "switch_6_0_Wireframe",
    "switch_7_0_Glow",
    "switch_8_0_Shading",
    "switch_9_0_Outline",
    "switch_10_0_Rainbow",
    "slider_11_0_255_0_Red",
    "slider_12_0_255_0_Green",
    "slider_13_0_255_0_Blue",
	};
	int Total_Feature = (sizeof features /
						 sizeof features[0]); // Теперь вам не нужно вручную обновлять количество каждый раз;

	ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
	int i;
	for (i = 0; i < Total_Feature; i++)
		env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
	return (ret);
}

JNIEXPORT void JNICALL
Java_il2cpp_Main_Changes(JNIEnv *env,jobject activityObject,jint feature,jint value) {
	/* ФУНКЦИИ  */
	switch (feature) {
		case 1: // Пример для существующего переключателя "Test"
			// Обработка переключателя Test (функция 1)
			LOGD("Test switch toggled, value: %d", value);
			break;
		case 2: // Пример для существующего слайдера "Sensitivity"
			// Обработка слайдера Sensitivity (функция 2)
			LOGD("Sensitivity slider changed, value: %d", value);
			break;
		case 3: // Скорость игрока (slider_3_0_0_100_PlayerSpeed)
			if (SetSpeed_Injected_Ptr && g_player_instance) {
				// Преобразуем значение jint в double для SetSpeed_Injected
				double speed = static_cast<double>(value);
				SetSpeed_Injected_Ptr(g_player_instance, speed);
				LOGD("Установлена скорость игрока: %.2f", speed);
			} else {
				LOGE("SetSpeed_Injected_Ptr или g_player_instance не инициализированы!");
			}
			break;
		case 4: // Уровень розыска (slider_4_0_0_5_WantedLevel)
			if (UpdateWantedLevel_Ptr && g_game_manager_instance) {
				// value уже является int
				UpdateWantedLevel_Ptr(g_game_manager_instance, value);
				LOGD("Установлен уровень розыска: %d", value);
			} else {
				LOGE("UpdateWantedLevel_Ptr или g_game_manager_instance не инициализированы!");
			}
			break;
		case 5: // Добавить деньги (button_5_AddMoney)
			if (AddMoney_Ptr && g_game_manager_instance) {
				// Для кнопки 'value' может быть 1 при нажатии.
				// Мы добавим фиксированную сумму, например, 1000.
				AddMoney_Ptr(g_game_manager_instance, 1000); // Добавляем 1000 денег
				LOGD("Добавлено 1000 денег.");
			} else {
				LOGE("AddMoney_Ptr или g_game_manager_instance не инициализированы!");
			}
			break;
        // --- Обработка функций чамсов ---
        case 6: // Wireframe
            wireframe = !wireframe;
            SetWallhackW(wireframe);
            LOGD("Wireframe: %d", wireframe);
            break;
        case 7: // Glow
            glow = !glow;
            SetWallhackG(glow);
            LOGD("Glow: %d", glow);
            break;
        case 8: // Shading
            shading = !shading;
            SetWallhackS(shading);
            LOGD("Shading: %d", shading);
            break;
        case 9: // Outline
            outline = !outline;
            SetWallhackO(outline);
            LOGD("Outline: %d", outline);
            break;
        case 10: // Rainbow
            rainbow = !rainbow;
            SetRainbow(rainbow);
            LOGD("Rainbow: %d", rainbow);
            break;
        case 11: // Red
            SetR(value);
            LOGD("Red: %d", value);
            break;
        case 12: // Green
            SetG(value);
            LOGD("Green: %d", value);
            break;
        case 13: // Blue
            SetB(value);
            LOGD("Blue: %d", value);
            break;
	}
}

// КОНЕЦ EXTERN
}

// ---------- Хукинг ---------- //

void *hack_thread(void *) {
	// Ждем загрузки библиотеки
	while (il2cpp_base == 0) {
		il2cpp_base = get_module_base(libName);
		if (il2cpp_base == 0) {
			LOGD("Ожидание загрузки %s...", libName);
			usleep(1000 * 1000); // Ждем 1 секунду
		}
	}
	LOGD("%s загружен по базовому адресу: 0x%lx", libName, il2cpp_base);

    // Вычисляем абсолютные адреса и присваиваем указателям на функции
    // RVA: 0x1B97CD0
    SetSpeed_Injected_Ptr = reinterpret_cast<SetSpeed_Injected_Fn>(il2cpp_base + 0x1B97CD0);
    // RVA: 0x58B158
    UpdateWantedLevel_Ptr = reinterpret_cast<UpdateWantedLevel_Fn>(il2cpp_base + 0x58B158);
    // RVA: 0x58BE84
    AddMoney_Ptr = reinterpret_cast<AddMoney_Fn>(il2cpp_base + 0x58BE84);

    // --- Инициализация чамсов ---
    mlovinit(); // Инициализация dlopen для libGLESv2.so
    setShader("unity_SHC"); // Установка имени шейдера для отслеживания
    LogShaders(); // Хук glGetUniformLocation
    Wallhack(); // Хук glDrawElements

    // --- ВАЖНО ---
    // В реальном сценарии моддинга игры вам потребуется найти фактические указатели 'this'
    // (например, g_player_instance, g_game_manager_instance) для объектов, которым принадлежат эти методы.
    // Это часто включает сканирование памяти на наличие определенных паттернов или хукинг конструкторов/методов
    // для захвата указателя 'this' при создании объекта.
    // Для этого примера они оставлены как nullptr, что означает, что вызовы в Changes()
    // завершатся неудачей, если вы не установите их вручную на основе конкретных экземпляров объектов вашей игры.
    // Например, если бы мы их нашли (это заполнитель для реальной логики):
    // g_player_instance = (void*)0xDEADBEEF; // Замените на реальный адрес экземпляра игрока
    // g_game_manager_instance = (void*)0xCAFEBABE; // Замените на реальный адрес экземпляра игрового менеджера

    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);

    // Создаем новый поток, чтобы он не блокировал основной поток, то есть игра не зависнет
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}


