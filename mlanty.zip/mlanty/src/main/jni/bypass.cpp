#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <android/log.h>
#include <stdio.h>
#include <stdarg.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/utsname.h>
#include <sys/system_properties.h> // Для __system_property_get

#define LOG_TAG "UltraBypass"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static const char* keywords[] = {
    "frida", "xposed", "substrate", "magisk", "su", "zygisk",
    "busybox", "supersu", "edxp", "reframework", "virtual", "vphone",
    "dualspace", "fake", "root", "patch", "debuggerd", "emulator",
    "nox", "bluestacks", "genymotion", "qemu", "android_x86",
    "MEmu", "LDPlayer", "vmware", "virtualbox", "hyper-v", "vbox", "vm",
    "com.topjohnwu.magisk", "/dev/frida", "/data/local/tmp/frida",
    "/system/xbin/su", "/system/bin/su", "/sbin/su", "/data/adb/magisk",
    "/proc/self/maps", "/proc/self/smaps", "TracerPid", "ro.debuggable",
    "ro.secure", "test-keys", "com.saurik.substrate", "com.soft.virtual",
    "com.lbe.parallel.intl", "com.excelliance.multiaccounts",
    "com.vmos.pro", "com.bignox.app", "com.bluestacks.app",
    "com.microvirt.me", "com.koplayer.app", "com.muemu.app",
    "com.google.android.apps.nexuslauncher",
    "goldfish", "vboxsf", "qemu_pipe", "android-emu", "generic_x86",
    "ro.hardware", "ro.board.platform", "ro.product.brand", "ro.product.model",
    "ro.build.fingerprint", "ro.boot.qemu", "ro.kernel.qemu",
    "ro.product.cpu.abi", "x86", "i686", "amd64", "intel",
    "/sys/class/dmi/id/", "/sys/bus/pci/", "/sys/devices/virtual/misc/qemu_pipe",
    "init.svc.qemud", "init.svc.console", "init.svc.adbd",
    "pipe:qemu_pipe", "pipe:goldfish_pipe",
    "vendor.qemu.driver", "vendor.goldfish.driver",
    "VBOX", "VMware", "QEMU", "KVM", "hypervisor",
    "VIRTUAL MACHINE", "VIRTUALBOX", "VMWARE",
    "00:0C:29", "00:50:56", "08:00:27", // Общие префиксы MAC-адресов ВМ
    "/dev/vboxguest", "/dev/vmhgfs", "/dev/kvm", "/dev/ttyS0",
    "VBoxGuestAdditions.iso", "vmtools.iso",
    "VBoxService", "vmtoolsd", "qemud", "emulator-console", "qemu-system-x86_64",
    "ro.hardware.egl", "ro.hardware.gralloc", // Свойства графического оборудования
    "GL_RENDERER", "GL_VENDOR", // Строки OpenGL рендерера/вендора
    "android_sdk_build", "sdk_phone_x86", "sdk_gphone_x86", // Свойства сборки SDK
    "generic", "unknown", "sdk", "google_sdk", // Общие имена устройств/сборок
    "serialno", "android_id", // Идентификаторы устройства
    "cpuinfo", "meminfo", "partitions", "version", "cmdline", // Имена файлов /proc
    "vendor_id", "model name", "flags", "Processor", "Hardware", // Ключевые слова информации о CPU
    "TotalMem", "SwapTotal", "MemTotal", "SwapFree", // Ключевые слова информации о памяти
    "system.img", "vendor.img", "ramdisk.img", // Имена файлов образов
    "build.prop", "default.prop", // Файлы свойств
    // Расширенные ro.boot.* свойства
    "ro.boot.hardware", "ro.boot.product", "ro.boot.console", "ro.boot.selinux",
    "ro.boot.secureboot", "ro.boot.verifiedbootstate", "ro.boot.flash.locked",
    "ro.boot.cid", "ro.boot.fsg-id", "ro.boot.emmc", "ro.boot.ram",
    "ro.boot.cpu", "ro.boot.board", "ro.boot.device", "ro.boot.revision",
    "ro.boot.chipname", "ro.boot.factory", "ro.boot.test", "ro.boot.debug",
    "ro.boot.eng", "ro.boot.perf", "ro.boot.mode", "ro.boot.alarm",
    "ro.boot.battery", "ro.boot.charger", "ro.boot.usb", "ro.boot.wifi",
    "ro.boot.bluetooth", "ro.boot.gps", "ro.boot.nfc", "ro.boot.camera",
    "ro.boot.audio", "ro.boot.display", "ro.boot.touch", "ro.boot.sensors",
    "ro.boot.fingerprint", "ro.boot.face", "ro.boot.ir", "ro.boot.led",
    "ro.boot.vibrator", "ro.boot.sdcard", "ro.boot.usbhost", "ro.boot.otg",
    "ro.boot.hdmi", "ro.boot.mhl", "ro.boot.displayport", "ro.boot.ethernet",
    "ro.boot.tethering", "ro.boot.hotspot", "ro.boot.vpn", "ro.boot.proxy",
    "ro.boot.apn", "ro.boot.network", "ro.boot.sim", "ro.boot.imei",
    "ro.boot.imsi", "ro.boot.msisdn", "ro.boot.iccid", "ro.boot.operator",
    "ro.boot.country", "ro.boot.locale", "ro.boot.timezone", "ro.boot.language",
    "ro.boot.region", "ro.boot.date", "ro.boot.time", "ro.boot.uptime",
    "ro.boot.boottime", "ro.boot.shutdownreason", "ro.boot.lastkmsg",
    "ro.boot.logcat", "ro.boot.dmesg", "ro.boot.console_loglevel",
    "ro.boot.printk", "ro.boot.panic", "ro.boot.reboot", "ro.boot.poweroff",
    "ro.boot.recovery", "ro.boot.fastboot", "ro.boot.download", "ro.boot.sideload",
    "ro.boot.wipe", "ro.boot.factoryreset", "ro.boot.ota", "ro.boot.update",
    "ro.boot.install", "ro.boot.verify", "ro.boot.check", "ro.boot.debuggable",
    "ro.boot.secure", "ro.boot.testkeys", "ro.boot.user", "ro.boot.eng",
    "ro.boot.prod", "ro.boot.release", "ro.boot.version", "ro.boot.build",
    "ro.boot.type", "ro.boot.id", "ro.boot.display.id", "ro.boot.tags",
    "ro.boot.description", "ro.boot.codename", "ro.boot.incremental",
    "ro.boot.base.os", "ro.boot.sdk", "ro.boot.api", "ro.boot.preview",
    "ro.boot.security.patch", "ro.boot.vendor.security.patch",
    "ro.kernel.version", "ro.kernel.compiler", "ro.kernel.date", "ro.kernel.time",
    "ro.kernel.arch", "ro.kernel.config", "ro.kernel.cmdline", "ro.kernel.ramdisk",
    "ro.kernel.dtb", "ro.kernel.fdt", "ro.kernel.modules", "ro.kernel.initrd",
    "ro.kernel.bootargs", "ro.kernel.cpu", "ro.kernel.gpu", "ro.kernel.mem",
    "ro.kernel.disk", "ro.kernel.network", "ro.kernel.bluetooth", "ro.kernel.wifi",
    "ro.kernel.gps", "ro.kernel.sensors", "ro.kernel.camera", "ro.kernel.audio",
    "ro.kernel.display", "ro.kernel.touch", "ro.kernel.battery", "ro.kernel.charger",
    "ro.kernel.usb", "ro.kernel.sdcard", "ro.kernel.fingerprint", "ro.kernel.face",
    "ro.kernel.ir", "ro.kernel.led", "ro.kernel.vibrator", "ro.kernel.nfc",
    "ro.kernel.ethernet", "ro.kernel.hdmi", "ro.kernel.mhl", "ro.kernel.displayport",
    "ro.kernel.otg", "ro.kernel.usbhost", "ro.kernel.tethering", "ro.kernel.hotspot",
    "ro.kernel.vpn", "ro.kernel.proxy", "ro.kernel.apn", "ro.kernel.network.type",
    "ro.kernel.sim", "ro.kernel.imei", "ro.kernel.imsi", "ro.kernel.msisdn",
    "ro.kernel.iccid", "ro.kernel.operator", "ro.kernel.country", "ro.kernel.locale",
    "ro.kernel.timezone", "ro.kernel.language", "ro.kernel.region", "ro.kernel.date",
    "ro.kernel.time", "ro.kernel.uptime", "ro.kernel.boottime", "ro.kernel.shutdownreason",
    "ro.kernel.lastkmsg", "ro.kernel.logcat", "ro.kernel.dmesg", "ro.kernel.console_loglevel",
    "ro.kernel.printk", "ro.kernel.panic", "ro.kernel.reboot", "ro.kernel.poweroff",
    "ro.kernel.recovery", "ro.kernel.fastboot", "ro.kernel.download", "ro.kernel.sideload",
    "ro.kernel.wipe", "ro.kernel.factoryreset", "ro.kernel.ota", "ro.kernel.update",
    "ro.kernel.install", "ro.kernel.verify", "ro.kernel.check", "ro.kernel.debuggable",
    "ro.kernel.secure", "ro.kernel.testkeys", "ro.kernel.user", "ro.kernel.eng",
    "ro.kernel.prod", "ro.kernel.release", "ro.kernel.version", "ro.kernel.build",
    "ro.kernel.type", "ro.kernel.id", "ro.kernel.display.id", "ro.kernel.tags",
    "ro.kernel.description", "ro.kernel.codename", "ro.kernel.incremental",
    "ro.kernel.base.os", "ro.kernel.sdk", "ro.kernel.api", "ro.kernel.preview",
    "ro.kernel.security.patch", "ro.kernel.vendor.security.patch",
    "ro.kernel.build.date", "ro.kernel.build.time", "ro.kernel.build.user",
    "ro.kernel.build.host", "ro.kernel.build.id", "ro.kernel.build.display.id",
    "ro.kernel.build.tags", "ro.kernel.build.description", "ro.kernel.build.codename",
    "ro.kernel.build.incremental", "ro.kernel.build.base.os", "ro.kernel.build.sdk",
    "ro.kernel.build.api", "ro.kernel.build.preview", "ro.kernel.build.security.patch",
    "ro.kernel.build.vendor.security.patch",
    "ro.product.device", "ro.product.manufacturer", "ro.board.name", "ro.bootmode",
    "ro.build.host", "ro.build.user", "ro.build.display.id", "ro.build.id",
    "ro.build.version.sdk", "ro.build.version.release", "ro.build.version.codename",
    "ro.boot.verifiedbootstate", "ro.boot.flash.locked", "ro.boot.secure", "ro.boot.selinux",
    "ro.boot.serialno", "ro.boot.cid", "ro.boot.baseband", "ro.boot.bootloader",
    "ro.boot.cpu", "ro.boot.ram", "ro.boot.storage",
    "ro.boot.kernel.version", "ro.boot.kernel.cmdline",
    "ro.boot.hardware.color", "ro.boot.hardware.sku", "ro.boot.hardware.revision",
    "ro.boot.dts", "ro.boot.dtb", "ro.boot.fdt", "ro.boot.fstab",
    "ro.boot.console", "ro.boot.androidboot", "ro.boot.androidboot.hardware",
    "ro.boot.androidboot.serialno", "ro.boot.androidboot.bootloader",
    "ro.boot.androidboot.baseband", "ro.boot.androidboot.cid",
    "ro.boot.androidboot.secureboot", "ro.boot.androidboot.verifiedbootstate",
    "ro.boot.androidboot.flash.locked",
    "ro.boot.androidboot.cpu", "ro.boot.androidboot.ram", "ro.boot.androidboot.storage",
    "ro.boot.androidboot.kernel.version", "ro.boot.androidboot.kernel.cmdline",
    "ro.boot.androidboot.hardware.color", "ro.boot.androidboot.hardware.sku",
    "ro.boot.androidboot.hardware.revision",
    "ro.boot.androidboot.debuggable", "ro.boot.androidboot.secure",
    "ro.boot.androidboot.testkeys", "ro.boot.androidboot.user",
    "ro.boot.androidboot.eng", "ro.boot.androidboot.prod",
    "ro.boot.androidboot.release", "ro.boot.androidboot.version",
    "ro.boot.androidboot.build", "ro.boot.androidboot.type",
    "ro.boot.androidboot.id", "ro.boot.androidboot.display.id",
    "ro.boot.androidboot.tags", "ro.boot.androidboot.description",
    "ro.boot.androidboot.codename", "ro.boot.androidboot.incremental",
    "ro.boot.androidboot.base.os", "ro.boot.androidboot.sdk",
    "ro.boot.androidboot.api", "ro.boot.androidboot.preview",
    "ro.boot.androidboot.security.patch", "ro.boot.androidboot.vendor.security.patch"
};
static const int keywords_count = sizeof(keywords)/sizeof(keywords[0]);

static bool contains_keyword(const char* str, size_t len) {
    if (!str || len == 0) return false;
    for (int i = 0; i < keywords_count; i++) {
        if (memmem(str, len, keywords[i], strlen(keywords[i])) != NULL) {
            return true;
        }
    }
    return false;
}

typedef int (*open_t)(const char*, int, ...);
typedef FILE* (*fopen_t)(const char*, const char*);
typedef ssize_t (*read_t)(int, void*, size_t);
typedef int (*access_t)(const char*, int);
typedef char* (*fgets_t)(char*, int, FILE*);
typedef int (*stat_t)(const char*, struct stat*);
typedef DIR* (*opendir_t)(const char*);
typedef struct dirent* (*readdir_t)(DIR*);
typedef ssize_t (*readlink_t)(const char*, char*, size_t);
typedef char* (*getenv_t)(const char*);
typedef void* (*dlopen_t)(const char*, int);
typedef int (*strcmp_t)(const char*, const char*);
typedef int (*__system_property_get_t)(const char*, char*);
typedef int (*uname_t)(struct utsname*);

static open_t orig_open = NULL;
static fopen_t orig_fopen = NULL;
static read_t orig_read = NULL;
static access_t orig_access = NULL;
static fgets_t orig_fgets = NULL;
static stat_t orig_stat = NULL;
static opendir_t orig_opendir = NULL;
static readdir_t orig_readdir = NULL;
static readlink_t orig_readlink = NULL;
static getenv_t orig_getenv = NULL;
static dlopen_t orig_dlopen = NULL;
static strcmp_t orig_strcmp = NULL;
static __system_property_get_t orig___system_property_get = NULL;
static uname_t orig_uname = NULL;

__attribute__((constructor))
static void init_hooks() {
    LOGI("Инициализация хуков UltraBypass...");
    orig_open = (open_t)dlsym(RTLD_NEXT, "open");
    orig_fopen = (fopen_t)dlsym(RTLD_NEXT, "fopen");
    orig_read = (read_t)dlsym(RTLD_NEXT, "read");
    orig_access = (access_t)dlsym(RTLD_NEXT, "access");
    orig_fgets = (fgets_t)dlsym(RTLD_NEXT, "fgets");
    orig_stat = (stat_t)dlsym(RTLD_NEXT, "stat");
    orig_opendir = (opendir_t)dlsym(RTLD_NEXT, "opendir");
    orig_readdir = (readdir_t)dlsym(RTLD_NEXT, "readdir");
    orig_readlink = (readlink_t)dlsym(RTLD_NEXT, "readlink");
    orig_getenv = (getenv_t)dlsym(RTLD_NEXT, "getenv");
    orig_dlopen = (dlopen_t)dlsym(RTLD_NEXT, "dlopen");
    orig_strcmp = (strcmp_t)dlsym(RTLD_NEXT, "strcmp");
    orig___system_property_get = (__system_property_get_t)dlsym(RTLD_NEXT, "__system_property_get");
    orig_uname = (uname_t)dlsym(RTLD_NEXT, "uname");

    if (!orig_open || !orig_fopen || !orig_read || !orig_access || !orig_fgets ||
        !orig_stat || !orig_opendir || !orig_readdir || !orig_readlink || !orig_getenv ||
        !orig_dlopen || !orig_strcmp || !orig___system_property_get || !orig_uname) {
        LOGI("Не удалось разрешить все указатели на оригинальные функции. Некоторые хуки могут не работать.");
    } else {
        LOGI("Все указатели на оригинальные функции успешно разрешены.");
    }
}

extern "C" {

int open(const char* path, int flags, ...) { // Хуки :3
    if (path && contains_keyword(path, strlen(path))) {
        LOGI("Заблокирован open: %s", path);
        errno = ENOENT;
        return -1;
    }
    va_list args;
    va_start(args, flags);
    int ret = (flags & O_CREAT) ? orig_open(path, flags, va_arg(args, int)) : orig_open(path, flags);
    va_end(args);
    return ret;
}

FILE* fopen(const char* path, const char* mode) { // Хуки :3
    if (path && contains_keyword(path, strlen(path))) {
        LOGI("Заблокирован fopen: %s", path);
        return orig_fopen("/dev/null", mode);
    }
    return orig_fopen(path, mode);
}

int access(const char* path, int mode) { // Хуки :3
    if (path && contains_keyword(path, strlen(path))) {
        LOGI("Заблокирован access: %s", path);
        return -1;
    }
    return orig_access(path, mode);
}

ssize_t read(int fd, void* buf, size_t count) { // Хуки :3
    ssize_t ret = orig_read(fd, buf, count);
    if (ret > 0 && buf) {
        for (int i = 0; i < keywords_count; ++i) {
            const char* kw = keywords[i];
            size_t len = strlen(kw);
            for (ssize_t j = 0; j <= ret - (ssize_t)len; ++j) {
                if (memcmp((char*)buf + j, kw, len) == 0) {
                    memset((char*)buf + j, '*', len);
                    LOGI("Отфильтровано ключевое слово при чтении: %s", kw);
                }
            }
        }
    }
    return ret;
}

char* fgets(char* str, int num, FILE* stream) { // Хуки :3
    char* res = orig_fgets(str, num, stream);
    if (res && str) {
        for (int i = 0; i < keywords_count; i++) {
            char* found = strstr(str, keywords[i]);
            while (found) {
                memset(found, '*', strlen(keywords[i]));
                found = strstr(found + 1, keywords[i]);
            }
        }
    }
    return res;
}

int stat(const char* path, struct stat* buf) { // Хуки :3
    if (path && contains_keyword(path, strlen(path))) {
        LOGI("Заблокирован stat: %s", path);
        errno = ENOENT;
        return -1;
    }
    return orig_stat(path, buf);
}

char* getenv(const char* name) { // Хуки :3
    if (name && contains_keyword(name, strlen(name))) {
        LOGI("Заблокирован getenv: %s", name);
        return NULL;
    }
    return orig_getenv(name);
}

DIR* opendir(const char* name) { // Хуки :3
    if (name && contains_keyword(name, strlen(name))) {
        LOGI("Заблокирован opendir: %s", name);
        errno = ENOENT;
        return NULL;
    }
    return orig_opendir(name);
}

struct dirent* readdir(DIR* dirp) { // Хуки :3
    if (!orig_readdir) orig_readdir = (readdir_t)dlsym(RTLD_NEXT, "readdir");
    struct dirent* entry;
    while ((entry = orig_readdir(dirp)) != NULL) {
        if (contains_keyword(entry->d_name, strlen(entry->d_name))) {
            LOGI("Отфильтрован readdir унос: %s", entry->d_name);
            continue;
        }
        return entry;
    }
    return NULL;
}

ssize_t readlink(const char* pathname, char* buf, size_t bufsiz) { // Хуки :3
    if (!orig_readlink) orig_readlink = (readlink_t)dlsym(RTLD_NEXT, "readlink");

    if (pathname && contains_keyword(pathname, strlen(pathname))) {
        LOGI("Заблокирован readlink для пути: %s", pathname);
        errno = ENOENT;
        return -1;
    }

    ssize_t ret = orig_readlink(pathname, buf, bufsiz);
    if (ret > 0 && buf) {
        if (contains_keyword(buf, ret)) {
            LOGI("Подделка readlink содержимого для: %s", pathname);
            const char* spoof_target = "/system/bin/app_process";
            size_t spoof_len = strlen(spoof_target);
            if (spoof_len < bufsiz) {
                strncpy(buf, spoof_target, bufsiz);
                buf[bufsiz - 1] = '\0';
                return spoof_len;
            } else {
                memset(buf, 0, bufsiz);
                return 0;
            }
        }
    }
    return ret;
}

int strcmp(const char* a, const char* b) { // Хуки :3
    if ((a && contains_keyword(a, strlen(a))) || (b && contains_keyword(b, strlen(b)))) {
        LOGI("Обойден strcmp на: [%s] vs [%s]", a ? a : "NULL", b ? b : "NULL");
        return 0;
    }
    return orig_strcmp(a, b);
}

void* dlopen(const char* filename, int flags) { // Хуки :3
    if (filename && contains_keyword(filename, strlen(filename))) {
        LOGI("Заблокирован dlopen: %s", filename);
        return NULL;
    }
    return orig_dlopen(filename, flags);
}

int __system_property_get(const char* name, char* value) { // Хуки :3
    if (!orig___system_property_get) orig___system_property_get = (__system_property_get_t)dlsym(RTLD_NEXT, "__system_property_get");

    // Подделка конкретных свойств для имитации реального устройства (Pixel 2)
    if (strcmp(name, "ro.build.fingerprint") == 0) {
        strncpy(value, "google/walleye/walleye:8.1.0/OPM1.171019.011/4448085:user/release-keys", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.fingerprint");
        return strlen(value);
    } else if (strcmp(name, "ro.product.brand") == 0) {
        strncpy(value, "google", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.product.brand");
        return strlen(value);
    } else if (strcmp(name, "ro.product.model") == 0) {
        strncpy(value, "Pixel 2", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.product.model");
        return strlen(value);
    } else if (strcmp(name, "ro.hardware") == 0) {
        strncpy(value, "walleye", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.hardware");
        return strlen(value);
    } else if (strcmp(name, "ro.board.platform") == 0) {
        strncpy(value, "msm8998", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.board.platform");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.qemu") == 0 || strcmp(name, "ro.kernel.qemu") == 0) {
        value[0] = '\0'; // Эти должны быть пустыми
        LOGI("Подделано QEMU свойство: %s", name);
        return 0;
    } else if (strcmp(name, "ro.build.type") == 0) {
        strncpy(value, "user", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.type");
        return strlen(value);
    } else if (strcmp(name, "ro.build.tags") == 0) {
        strncpy(value, "release-keys", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.tags");
        return strlen(value);
    } else if (strcmp(name, "ro.debuggable") == 0) {
        strncpy(value, "0", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.debuggable");
        return strlen(value);
    } else if (strcmp(name, "ro.product.device") == 0) {
        strncpy(value, "walleye", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.product.device");
        return strlen(value);
    } else if (strcmp(name, "ro.product.manufacturer") == 0) {
        strncpy(value, "Google", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.product.manufacturer");
        return strlen(value);
    } else if (strcmp(name, "ro.board.name") == 0) {
        strncpy(value, "walleye", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.board.name");
        return strlen(value);
    } else if (strcmp(name, "ro.bootmode") == 0) {
        strncpy(value, "normal", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.bootmode");
        return strlen(value);
    } else if (strcmp(name, "ro.build.host") == 0) {
        strncpy(value, "abfarm-001.google.com", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.host");
        return strlen(value);
    } else if (strcmp(name, "ro.build.user") == 0) {
        strncpy(value, "android-build", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.user");
        return strlen(value);
    } else if (strcmp(name, "ro.build.display.id") == 0) {
        strncpy(value, "OPM1.171019.011", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.display.id");
        return strlen(value);
    } else if (strcmp(name, "ro.build.id") == 0) {
        strncpy(value, "OPM1.171019.011", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.id");
        return strlen(value);
    } else if (strcmp(name, "ro.build.version.sdk") == 0) {
        strncpy(value, "26", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.version.sdk");
        return strlen(value);
    } else if (strcmp(name, "ro.build.version.release") == 0) {
        strncpy(value, "8.0.0", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.version.release");
        return strlen(value);
    } else if (strcmp(name, "ro.build.version.codename") == 0) {
        strncpy(value, "REL", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.build.version.codename");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.verifiedbootstate") == 0) {
        strncpy(value, "green", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.verifiedbootstate");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.flash.locked") == 0) {
        strncpy(value, "1", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.flash.locked");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.secure") == 0) {
        strncpy(value, "1", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.secure");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.selinux") == 0) {
        strncpy(value, "enforcing", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.selinux");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.serialno") == 0) {
        strncpy(value, "FA79K1A00000", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.serialno");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.cid") == 0) {
        strncpy(value, "00000000", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.cid");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.baseband") == 0) {
        strncpy(value, "g8998-00000-1709261234", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.baseband");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.bootloader") == 0) {
        strncpy(value, "walleye-bootloader-00.00.0000", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.bootloader");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.cpu") == 0) {
        strncpy(value, "ARM", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.cpu");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.ram") == 0) {
        strncpy(value, "4096MB", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.ram");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.storage") == 0) {
        strncpy(value, "UFS", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.storage");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.kernel.version") == 0) {
        strncpy(value, "4.19.112-g6a9925621c1", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.kernel.version");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.kernel.cmdline") == 0) {
        strncpy(value, "androidboot.hardware=walleye buildvariant=userdebug", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.kernel.cmdline");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.hardware.color") == 0) {
        strncpy(value, "black", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.hardware.color");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.hardware.sku") == 0) {
        strncpy(value, "G011C", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.hardware.sku");
        return strlen(value);
    } else if (strcmp(name, "ro.boot.hardware.revision") == 0) {
        strncpy(value, "1.0", PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGI("Подделан ro.boot.hardware.revision");
        return strlen(value);
    }


    if (name && contains_keyword(name, strlen(name))) {
        LOGI("Блокирован __system_property_get для свойства: %s", name);
        if (value) {
            value[0] = '\0';
        }
        return 0;
    }
    return orig___system_property_get(name, value);
}

int uname(struct utsname* buf) { // Хуки :3
    int ret = orig_uname(buf);
    if (ret == 0) {
        LOGI("Подделка uname вывода.");
        strncpy(buf->sysname, "Linux", sizeof(buf->sysname) - 1);
        buf->sysname[sizeof(buf->sysname) - 1] = '\0';

        strncpy(buf->nodename, "android", sizeof(buf->nodename) - 1);
        buf->nodename[sizeof(buf->nodename) - 1] = '\0';

        strncpy(buf->release, "4.19.112-g6a9925621c1", sizeof(buf->release) - 1);
        buf->release[sizeof(buf->release) - 1] = '\0';

        strncpy(buf->version, "#1 SMP PREEMPT Mon Jul 24 12:34:56 UTC 2025", sizeof(buf->version) - 1);
        buf->version[sizeof(buf->version) - 1] = '\0';

        strncpy(buf->machine, "aarch64", sizeof(buf->machine) - 1);
        buf->machine[sizeof(buf->machine) - 1] = '\0';

        strncpy(buf->domainname, "android", sizeof(buf->domainname) - 1);
        buf->domainname[sizeof(buf->domainname) - 1] = '\0';
    }
    return ret;
}

}

