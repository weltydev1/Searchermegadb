package il2cpp.typefaces;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.inputmethod.InputMethodManager;
import il2cpp.*;
import android.text.*;
import android.view.Window.*;
import android.text.method.*;
import android.graphics.Typeface;
import android.util.*;
import android.view.*;
import android.widget.*;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import java.io.*;
import java.util.Objects;
import android.widget.LinearLayout.LayoutParams;
import java.util.ArrayList;
import android.view.View.OnClickListener;
import il2cpp.typefaces.*;

public class Menu
{
	protected int WIDTH,HEIGHT;

	public Typeface google(Context yes) {return Typeface.createFromAsset(yes.getAssets(), "Font.ttf");}

	protected Context context;
	protected FrameLayout _parentBox;
	protected LinearLayout __page;
	protected ScrollView __scroll;

	public ArrayList<PageButton> _pagebuttons = new ArrayList<>();
	public ArrayList<LinearLayout> __pages = new ArrayList<>();

	public ImageView _icon;
	public TextView __pagetitle;
	public ImageView __pagesrc;
	boolean _isShow = false;

	LinearLayout menulayout,_close,linear8,_pages,linear10,_scroll;
	TextView textview12;


	protected WindowManager wmManager;
	protected WindowManager.LayoutParams wmParams;

	protected void init(Context context) {

		this.context = context;

		_parentBox = new FrameLayout(context);

		_parentBox.setOnTouchListener(handleMotionTouch);
		wmManager = ((Activity)context).getWindowManager();
		int aditionalFlags=0;
		if (Build.VERSION.SDK_INT >= 11)
			aditionalFlags = WindowManager.LayoutParams.FLAG_SPLIT_TOUCH;
		if (Build.VERSION.SDK_INT >=  3)
			aditionalFlags = aditionalFlags | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM;
		wmParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			0,//initialX
			0,//initialy
			WindowManager.LayoutParams.TYPE_APPLICATION,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_OVERSCAN |
			WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
			aditionalFlags,
			PixelFormat.TRANSPARENT
		);
		wmParams.gravity = Gravity.CENTER;
	}

	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}

	public void showMenu() {
		_isShow = true;
		_parentBox.removeAllViews();
		_parentBox.addView(menulayout);

		ObjectAnimator scaleAlphaUp = ObjectAnimator.ofPropertyValuesHolder(menulayout,
																			PropertyValuesHolder.ofFloat("scaleX", 0f, 1.0f),
																			PropertyValuesHolder.ofFloat("scaleY", 0f, 1.0f),
																			PropertyValuesHolder.ofFloat("alpha", 0f, 1.0f));
		scaleAlphaUp.setDuration(350);
		scaleAlphaUp.start();
	}

	public void hideMenu() {
		_isShow = false;
		ObjectAnimator scaleAlphaDown = ObjectAnimator.ofPropertyValuesHolder(menulayout,
																			  PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0f),
																			  PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0f),
																			  PropertyValuesHolder.ofFloat("alpha", 1.0f, 0f));
		scaleAlphaDown.setDuration(350);
		scaleAlphaDown.start();
		new Handler().postDelayed(new Runnable() {
				public void run() {
					_parentBox.removeAllViews();
					_parentBox.addView(_icon, dpi(50), dpi(50));
					Utils.anim(_icon, 200);
				}
			}, 350);
	}

	public void newPage(final String nm, final String src) {
		LinearLayout _page = new LinearLayout(context);
		PageButton _butt = new PageButton(context, nm, src);
		final int pageid = __pages.size();
		__page.setOrientation(LinearLayout.VERTICAL);
		_page.setOrientation(LinearLayout.VERTICAL);
		__page.addView(_page, -1, -1);
		_page.setVisibility(View.GONE);
		__pages.add(_page);
		_butt.callback = new PageButton.Callback() {
			public void onClick() {
				__pagetitle.setText(nm);
				Utils.SetAssets(context, __pagesrc, src);
				showPage(pageid);
			}
		};

		_pagebuttons.add(_butt);
		_pages.addView(_butt);
	}

	public void showPage(final int id) {
		for (PageButton pg: _pagebuttons) {
			pg.hide();
		}
		for (LinearLayout layout: __pages) {
			layout.setVisibility(View.GONE);
		}
		__pages.get(id).setVisibility(View.VISIBLE);
		_pagebuttons.get(id).show();
		Utils.anim(__pages.get(id), 400);
	}

	public Menu(Context context)
	{
		init(context);

		_icon = new ImageView(context);
		Utils.SetAssets(context, _icon, "icon.png");

		menulayout = new LinearLayout(context);
		{
			menulayout.setOrientation(1);
			menulayout.setPadding(dpi(10), dpi(10), dpi(10), dpi(10));
			menulayout.setGravity(Gravity.TOP | Gravity.START);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.parseColor("#F0F0F0"));
			design.setCornerRadius(dpi(15));

            design.setStroke(dpi(3), Color.parseColor("#00FFFF"));

			menulayout.setBackgroundDrawable(design);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				menulayout.setElevation(dpi(8));
			}

			LayoutParams lp = new LayoutParams(dpi(420), dpi(350), 0);
			lp.leftMargin   = 0;
			lp.topMargin    = 0;
			lp.rightMargin  = 0;
			lp.bottomMargin = 0;
			menulayout.setLayoutParams(lp);
		}

		_close = new LinearLayout(context);
		{
			_close.setOrientation(1);
			_close.setPadding(dpi(10), dpi(10), dpi(10), dpi(10));
			_close.setGravity(Gravity.CENTER);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.parseColor("#424242"));
			design.setCornerRadii(new float[] { dpi(15), dpi(15), dpi(15), dpi(15), 0.0f, 0.0f, 0.0f, 0.0f });
			_close.setBackgroundDrawable(design);
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
				_close.setElevation(dpi(4));
			}

			LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, dpi(56), 0);
			lp.leftMargin   = 0;
			lp.topMargin    = 0;
			lp.rightMargin  = 0;
			lp.bottomMargin = dpi(10);
			_close.setLayoutParams(lp);
		}
		menulayout.addView(_close);

		textview12 = new TextView(context);
		{
			textview12.setText("WORM Modding | By ALOGEN");
			textview12.setPadding(dpi(5), dpi(5), dpi(5), dpi(5));
			textview12.setGravity(Gravity.CENTER);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.TRANSPARENT);
			textview12.setBackgroundDrawable(design);

			LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 0);
			textview12.setLayoutParams(lp);
			textview12.setTextColor(Color.WHITE);
			textview12.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.0f);
			textview12.setTypeface(Utils.font(context));
		}
		_close.addView(textview12);

		linear8 = new LinearLayout(context);
		{
			linear8.setOrientation(0);
			linear8.setPadding(0, 0, 0, 0);
			linear8.setGravity(Gravity.TOP | Gravity.START);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.TRANSPARENT);
			linear8.setBackgroundDrawable(design);

			LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 0);
			linear8.setLayoutParams(lp);
		}
		menulayout.addView(linear8);

		_pages = new LinearLayout(context);
		{
			_pages.setOrientation(1);
			_pages.setPadding(dpi(5), dpi(5), dpi(5), dpi(5));
			_pages.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.parseColor("#E0E0E0"));
			design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, dpi(15), dpi(15), dpi(15), dpi(15) });
			_pages.setBackgroundDrawable(design);

			LayoutParams lp = new LayoutParams(dpi(120), LayoutParams.MATCH_PARENT, 0);
			lp.rightMargin = dpi(10);
			_pages.setLayoutParams(lp);
		}
		linear8.addView(_pages);

		linear10 = new LinearLayout(context);
		{
			linear10.setOrientation(1);
			linear10.setPadding(0, 0, 0, 0);
			linear10.setGravity(Gravity.TOP | Gravity.START);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.parseColor("#CCCCCC"));
			linear10.setBackgroundDrawable(design);

			LayoutParams lp = new LayoutParams(dpi(1), LayoutParams.MATCH_PARENT, 0);
			lp.rightMargin = dpi(10);
			linear10.setLayoutParams(lp);
		}
		linear8.addView(linear10);

		_scroll = new LinearLayout(context);
		{
			_scroll.setOrientation(1);
			_scroll.setPadding(dpi(5), dpi(5), dpi(5), dpi(5));
			_scroll.setGravity(Gravity.TOP | Gravity.START);

			GradientDrawable design = new GradientDrawable();
			design.setColor(Color.WHITE);
			design.setCornerRadii(new float[] { 0.0f, 0.0f, 0.0f, 0.0f, dpi(15), dpi(15), dpi(15), dpi(15) });
			_scroll.setBackgroundDrawable(design);

			LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 1.0f);
			_scroll.setLayoutParams(lp);
		}
		linear8.addView(_scroll);
		LinearLayout _underpages = new LinearLayout(context);

		TextView _pagetitle = new TextView(context);

		ImageView _pagesrc = new ImageView(context);

		__pagetitle = _pagetitle;
		__pagesrc = _pagesrc;

		_close.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					hideMenu();
				}
			});

		__scroll = new ScrollView(context);
		__scroll.setFillViewport(true);

		__page = new LinearLayout(context);
		__page.setOrientation(LinearLayout.VERTICAL);

		__scroll.addView(__page, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		_scroll.addView(__scroll, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);

		hideMenu();
		wmManager.addView(_parentBox, wmParams);

        // Создаем final локальную ссылку на context
        final Context finalContext = this.context;

        // Показываем кастомное диалоговое окно при инициализации меню
        CustomAlertDialog dialog = new CustomAlertDialog(finalContext);
        dialog.show();

        // Показываем диалоговое окно авторизации после CustomAlertDialog
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
				@Override
				public void onDismiss(DialogInterface dialogInterface) {
					AuthDialog authDialog = new AuthDialog(finalContext, new AuthDialog.AuthDialogCallback() {
							@Override
							public void onAuthSuccess() {
								// Здесь можно добавить логику, которая должна выполняться после успешной авторизации
								// Например, показать основное меню
								// showMenu(); // если нужно показать меню сразу после авторизации
							}
						});
					authDialog.show();
				}
			});
	}

	View.OnTouchListener handleMotionTouch = new View.OnTouchListener()
	{
		private float initX;
		private float initY;
		private float touchX;
		private float touchY;

		double clock=0;

		@Override
		public boolean onTouch(View vw, MotionEvent ev)
		{

			switch (ev.getAction())
			{
				case MotionEvent.ACTION_DOWN:

					initX = wmParams.x;
					initY = wmParams.y;
					touchX = ev.getRawX();
					touchY = ev.getRawY();
					clock = System.currentTimeMillis();
					break;

				case MotionEvent.ACTION_MOVE:
					wmParams.x = (int)initX + (int)(ev.getRawX() - touchX);

					wmParams.y = (int)initY + (int)(ev.getRawY() - touchY);


					wmManager.updateViewLayout(vw, wmParams);
					break;

				case MotionEvent.ACTION_UP:
					if (!_isShow && (System.currentTimeMillis() < (clock + 200)))
					{
						showMenu();
					}
					break;
			}
			return true;
		}
	};
}


