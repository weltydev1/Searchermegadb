package il2cpp.typefaces;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.ColorDrawable;
import il2cpp.Utils; // Предполагается, что этот класс существует

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class AuthDialog extends Dialog {

    private final Context context;
    private EditText keyInput;
    private TextView statusText;
    private static final String KEYS_URL = "https://gist.githubusercontent.com/weltydev1/88aa40cd1cf9c58d26b3a76a0332c197/raw/example.txt";
    private static final String GET_KEY_TELEGRAM_LINK = "http://t.me/DesFleksWarebot";
    private AuthDialogCallback callback;

    // Интерфейс для обратного вызова, когда авторизация успешна
    public interface AuthDialogCallback {
        void onAuthSuccess();
    }

    public AuthDialog(Context context, AuthDialogCallback callback) {
        super(context);
        this.context = context;
        this.callback = callback;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createDialogView());
        setCancelable(false); // Нельзя закрыть диалог без авторизации
        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    private View createDialogView() {
        LinearLayout mainLayout = new LinearLayout(context);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setGravity(Gravity.CENTER_HORIZONTAL);
        mainLayout.setPadding(Utils.dp(context, 20), Utils.dp(context, 20), Utils.dp(context, 20), Utils.dp(context, 20));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#FFFFFF"));
        background.setCornerRadius(Utils.dp(context, 15));
        mainLayout.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mainLayout.setElevation(Utils.dp(context, 10));
        }

        TextView titleText = new TextView(context);
        titleText.setText("Авторизация");
        titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        titleText.setTextColor(Color.parseColor("#212121"));
        titleText.setTypeface(Utils.font(context));
        titleText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = Utils.dp(context, 15);
        titleText.setLayoutParams(titleLp);
        mainLayout.addView(titleText);

        keyInput = new EditText(context);
        keyInput.setHint("Введите ключ");
        keyInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        keyInput.setTextColor(Color.parseColor("#424242"));
        keyInput.setHintTextColor(Color.parseColor("#9E9E9E"));
        keyInput.setSingleLine(true);
        keyInput.setGravity(Gravity.CENTER_VERTICAL);
        keyInput.setPadding(Utils.dp(context, 10), Utils.dp(context, 10), Utils.dp(context, 10), Utils.dp(context, 10));

        GradientDrawable inputBackground = new GradientDrawable();
        inputBackground.setColor(Color.parseColor("#F5F5F5"));
        inputBackground.setCornerRadius(Utils.dp(context, 8));
        inputBackground.setStroke(Utils.dp(context, 1), Color.parseColor("#E0E0E0"));
        keyInput.setBackground(inputBackground);

        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(
			Utils.dp(context, 250), LinearLayout.LayoutParams.WRAP_CONTENT);
        inputLp.bottomMargin = Utils.dp(context, 15);
        keyInput.setLayoutParams(inputLp);
        mainLayout.addView(keyInput);

        statusText = new TextView(context);
        statusText.setText("");
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statusText.setTextColor(Color.RED);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        statusLp.bottomMargin = Utils.dp(context, 15);
        statusText.setLayoutParams(statusLp);
        mainLayout.addView(statusText);

        Button checkKeyButton = new Button(context);
        checkKeyButton.setText("Проверить ключ");
        checkKeyButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        checkKeyButton.setTextColor(Color.WHITE);

        GradientDrawable checkButtonBackground = new GradientDrawable();
        checkButtonBackground.setColor(Color.parseColor("#4CAF50")); // Green
        checkButtonBackground.setCornerRadius(Utils.dp(context, 10));
        checkKeyButton.setBackground(checkButtonBackground);

        LinearLayout.LayoutParams checkButtonLp = new LinearLayout.LayoutParams(
			Utils.dp(context, 200), Utils.dp(context, 50));
        checkButtonLp.bottomMargin = Utils.dp(context, 10);
        checkKeyButton.setLayoutParams(checkButtonLp);

        checkKeyButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					String enteredKey = keyInput.getText().toString().trim();
					if (enteredKey.isEmpty()) {
						statusText.setText("Пожалуйста, введите ключ.");
						return;
					}
					statusText.setText("Проверка ключа...");
					statusText.setTextColor(Color.parseColor("#2196F3")); // Blue for loading
					new CheckKeyTask().execute(enteredKey);
				}
			});
        mainLayout.addView(checkKeyButton);

        Button getKeyButton = new Button(context);
        getKeyButton.setText("Получить ключ");
        getKeyButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        getKeyButton.setTextColor(Color.WHITE);

        GradientDrawable getButtonBackground = new GradientDrawable();
        getButtonBackground.setColor(Color.parseColor("#2196F3")); // Blue
        getButtonBackground.setCornerRadius(Utils.dp(context, 10));
        getKeyButton.setBackground(getButtonBackground);

        LinearLayout.LayoutParams getButtonLp = new LinearLayout.LayoutParams(
			Utils.dp(context, 200), Utils.dp(context, 50));
        getKeyButton.setLayoutParams(getButtonLp);

        getKeyButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(GET_KEY_TELEGRAM_LINK));
					context.startActivity(browserIntent);
				}
			});
        mainLayout.addView(getKeyButton);

        return mainLayout;
    }

    private class CheckKeyTask extends AsyncTask<String, Void, Boolean> {
        private String enteredKey;

        @Override
        protected Boolean doInBackground(String... params) {
            enteredKey = params[0];
            try {
                URL url = new URL(KEYS_URL);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.trim().equals(enteredKey)) {
                        reader.close();
                        connection.disconnect();
                        return true;
                    }
                }
                reader.close();
                connection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
                return false; // Ошибка при загрузке или проверке
            }
            return false;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            if (result) {
                statusText.setText("Ключ принят!");
                statusText.setTextColor(Color.parseColor("#4CAF50")); // Green for success
                // Задержка перед закрытием, чтобы пользователь увидел сообщение
                new android.os.Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							dismiss();
							if (callback != null) {
								callback.onAuthSuccess(); // Вызываем колбэк при успешной авторизации
							}
						}
					}, 1000); // 1 секунда задержки
            } else {
                statusText.setText("Неверный ключ или ошибка сети.");
                statusText.setTextColor(Color.RED); // Red for failure
            }
        }
    }
}


