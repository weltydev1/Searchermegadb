package il2cpp.typefaces;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import il2cpp.Utils;
import android.util.TypedValue; // Для sp единиц

public class Slider extends LinearLayout {
	Context context;
	public TextView title, value;
	public SeekBar slider;

	public static interface Callback {
		public void onChange(int value);
	}
	public Callback callback;

	// Определяем цвета для красивого дизайна
	private final int COLOR_ACCENT = Color.parseColor("#4285F4"); // Яркий синий (Google Blue)
	private final int COLOR_TRACK_BACKGROUND = Color.parseColor("#E0E0E0"); // Светло-серый для незаполненной части
	private final int COLOR_TEXT = Color.parseColor("#212121"); // Темно-серый для текста
	private final int COLOR_THUMB_BORDER = Color.WHITE; // Белая рамка для ползунка

	public void setValue(int v) {
		slider.setProgress(v);
		value.setText(String.valueOf(v));
		if (callback != null) callback.onChange(v);
	}

	public Slider(Context context, String text, int max, int current) {
		super(context);
		this.context = context;

		setOrientation(LinearLayout.VERTICAL); // Изменено на вертикальную ориентацию для лучшего расположения заголовка/значения и ползунка
		setPadding(Utils.dp(context, 16), Utils.dp(context, 8), Utils.dp(context, 16), Utils.dp(context, 8)); // Больше отступов
		setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT)); // Высота по содержимому

		// Верхний макет для заголовка и значения
		LinearLayout topLayout = new LinearLayout(context);
		topLayout.setOrientation(LinearLayout.HORIZONTAL);
		topLayout.setGravity(Gravity.CENTER_VERTICAL);
		LayoutParams topLp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		topLp.bottomMargin = Utils.dp(context, 8); // Отступ между текстом и ползунком
		topLayout.setLayoutParams(topLp);
		addView(topLayout);

		title = new TextView(context);
		{ // Текст слайдера
			title.setText(text + ": ");
			title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.0f); // Увеличенный размер текста
			title.setTypeface(Utils.font(context));
			title.setTextColor(COLOR_TEXT);
			title.setGravity(Gravity.CENTER_VERTICAL);
			topLayout.addView(title, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.0f)); // Занимает оставшееся пространство
		}

		value = new TextView(context);
		{ // Текст значения слайдера
			value.setText(String.valueOf(current));
			value.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.0f); // Увеличенный размер текста
			value.setTypeface(Utils.font(context));
			value.setTextColor(COLOR_TEXT);
			value.setGravity(Gravity.CENTER_VERTICAL | Gravity.END); // Выравнивание по концу
			topLayout.addView(value, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
		}

		slider = new SeekBar(context);
		{ // Дизайн SeekBar
			slider.setMax(max);
			slider.setProgress(current);

			// Пользовательский Drawable для ползунка (Thumb)
			GradientDrawable thumb = new GradientDrawable();
			thumb.setShape(GradientDrawable.OVAL); // Круглая форма
			thumb.setColor(COLOR_ACCENT); // Цвет ползунка
			thumb.setSize(Utils.dp(context, 24), Utils.dp(context, 24)); // Размер ползунка
			thumb.setStroke(Utils.dp(context, 2), COLOR_THUMB_BORDER); // Белая рамка
			slider.setThumb(thumb);

			// Пользовательский Drawable для дорожки (ProgressDrawable)
			// Фон дорожки (незаполненная часть)
			GradientDrawable trackBackground = new GradientDrawable();
			trackBackground.setShape(GradientDrawable.RECTANGLE);
			trackBackground.setColor(COLOR_TRACK_BACKGROUND);
			trackBackground.setCornerRadius(Utils.dp(context, 4)); // Закругленные углы для дорожки

			// Прогресс дорожки (заполненная часть)
			GradientDrawable trackProgress = new GradientDrawable();
			trackProgress.setShape(GradientDrawable.RECTANGLE);
			trackProgress.setColor(COLOR_ACCENT);
			trackProgress.setCornerRadius(Utils.dp(context, 4)); // Закругленные углы для дорожки

			// Обрезаем прогресс Drawable, чтобы он заполнялся слева
			ClipDrawable progressClip = new ClipDrawable(trackProgress, Gravity.START, ClipDrawable.HORIZONTAL);

			// LayerDrawable для дорожки (фон + прогресс)
			Drawable[] layers = {trackBackground, progressClip};
			LayerDrawable progressDrawable = new LayerDrawable(layers);
			progressDrawable.setId(0, android.R.id.background); // ID для фона
			progressDrawable.setId(1, android.R.id.progress); // ID для прогресса

			slider.setProgressDrawable(progressDrawable);

			// Устанавливаем высоту для самого SeekBar
			LayoutParams sliderLp = new LayoutParams(LayoutParams.MATCH_PARENT, Utils.dp(context, 10)); // Высота дорожки
			slider.setLayoutParams(sliderLp);

			slider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
					@Override
					public void onProgressChanged(SeekBar sl, int v, boolean b) {
						setValue(v);
					}

					@Override
					public void onStopTrackingTouch(SeekBar sl) {}
					@Override
					public void onStartTrackingTouch(SeekBar sl) {}
				});
		}
		addView(slider);

		setValue(current); // Устанавливаем начальное значение и вызываем колбэк
	}
}


