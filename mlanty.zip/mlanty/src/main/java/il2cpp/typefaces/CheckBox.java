package il2cpp.typefaces;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import il2cpp.Utils; // Предполагается, что Utils содержит метод dp() и font()

public class CheckBox extends LinearLayout {
	Context context;

	public LinearLayout checkbox;
	public TextView title;
	public TextView checkmark; // Добавляем TextView для галочки

	public boolean isChecked = false;
	public Callback callback;

	// Новые цвета для красивого дизайна
	public int colorChecked = Color.parseColor("#4CAF50"); // Ярко-зеленый для отмеченного состояния
	public int colorUncheckedBorder = Color.parseColor("#9E9E9E"); // Серый для рамки неотмеченного состояния
	public int colorText = Color.parseColor("#212121"); // Темно-серый для текста

	public static interface Callback {
		public void onChanged(boolean checked);
	}

	// Метод для установки фона чекбокса
	private void applyCheckboxBackground(boolean checked) {
		GradientDrawable grad = new GradientDrawable();
		grad.setShape(GradientDrawable.RECTANGLE);
		grad.setCornerRadius(Utils.dp(context, 6)); // Закругленные углы

		if (checked) {
			grad.setColor(colorChecked);
			grad.setStroke(0, Color.TRANSPARENT); // Нет рамки, когда отмечено
		} else {
			grad.setColor(Color.TRANSPARENT); // Прозрачный фон
			grad.setStroke(Utils.dp(context, 2), colorUncheckedBorder); // Тонкая серая рамка
		}
		checkbox.setBackgroundDrawable(grad);
	}

	public void setChecked(boolean isch) {
		if (isChecked == isch) return; // Избегаем повторных вызовов, если состояние не изменилось

		isChecked = isch;
		if (callback != null) callback.onChanged(isChecked);

		if (isChecked) {
			// Анимация для галочки: появление
			checkmark.setVisibility(View.VISIBLE);
			ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(checkmark, "alpha", 0f, 1f);
			alphaAnimator.setDuration(200);
			alphaAnimator.start();

			// Анимация для фона чекбокса: изменение цвета
			applyCheckboxBackground(true);
			ObjectAnimator scaleAnimator = ObjectAnimator.ofPropertyValuesHolder(checkbox,
																				 PropertyValuesHolder.ofFloat("scaleX", 0.8f, 1.0f),
																				 PropertyValuesHolder.ofFloat("scaleY", 0.8f, 1.0f));
			scaleAnimator.setDuration(250);
			scaleAnimator.start();

		} else {
			// Анимация для галочки: исчезновение
			ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(checkmark, "alpha", 1f, 0f);
			alphaAnimator.setDuration(200);
			alphaAnimator.start();
			alphaAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
					@Override
					public void onAnimationEnd(android.animation.Animator animation) {
						checkmark.setVisibility(View.GONE);
					}
				});

			// Анимация для фона чекбокса: изменение цвета
			applyCheckboxBackground(false);
			ObjectAnimator scaleAnimator = ObjectAnimator.ofPropertyValuesHolder(checkbox,
																				 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0.8f),
																				 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0.8f));
			scaleAnimator.setDuration(250);
			scaleAnimator.start();
		}
	}

	public void setCallback(Callback call) {
		callback = call;
	}

	public void setText(String t) {
		title.setText(t);
	}

	public CheckBox(Context ctx) {
		super(ctx);
		context = ctx;

		setOrientation(LinearLayout.HORIZONTAL);
		setGravity(Gravity.CENTER_VERTICAL); // Выравнивание по центру по вертикали
		setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, Utils.dp(context, 30))); // Увеличил высоту для лучшего вида

		checkbox = new LinearLayout(context);
		{ // CheckBox container
			checkbox.setGravity(Gravity.CENTER);
			LayoutParams lp = new LayoutParams(Utils.dp(context, 24), Utils.dp(context, 24)); // Размер чекбокса
			lp.rightMargin = Utils.dp(context, 10); // Отступ от текста
			checkbox.setLayoutParams(lp);
			applyCheckboxBackground(false); // Изначально неотмечен
		}

		checkmark = new TextView(context);
		{ // Checkmark (галочка)
			checkmark.setText("✓"); // Символ галочки
			checkmark.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); // Размер галочки
			checkmark.setTextColor(Color.WHITE); // Белый цвет галочки
			checkmark.setGravity(Gravity.CENTER);
			checkmark.setVisibility(View.GONE); // Изначально скрыта
			checkbox.addView(checkmark, LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		}

		title = new TextView(context);
		{ // Checkbox text
			title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.0f); // Размер текста
			title.setTypeface(Utils.font(context));
			title.setTextColor(colorText); // Темно-серый цвет текста
			title.setGravity(Gravity.CENTER_VERTICAL);
			title.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
		}

		OnClickListener clck;
		{ // Click listener
			clck = new OnClickListener() {
				public void onClick(View v) {
					setChecked(!isChecked);
				}
			};
			// Назначаем слушатель кликов на весь CheckBox, чтобы было удобнее нажимать
			setOnClickListener(clck);
		}

		addView(checkbox);
		addView(title);

		setChecked(false); // Устанавливаем начальное состояние
	}
}


