package il2cpp.typefaces;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import il2cpp.Utils; // Предполагается, что Utils содержит метод dp() и font()

public class PageButton extends LinearLayout {
	Context context;

	public static interface Callback {
		public void onClick();
	}
	public Callback callback;

	// Визуальный индикатор активной страницы
	private View activeIndicator;
	// Основной контейнер для иконки и текста
	private LinearLayout contentLayout;

	TextView _pagetitle;
	ImageView _pagesrc;

	// Цвета для дизайна
	private final int COLOR_DEFAULT_BACKGROUND = Color.parseColor("#F5F5F5"); // Светло-серый фон
	private final int COLOR_ACTIVE_BACKGROUND = Color.parseColor("#E0E0E0"); // Чуть темнее серый для активного
	private final int COLOR_INDICATOR = Color.parseColor("#4CAF50"); // Зеленый для индикатора
	private final int COLOR_TEXT = Color.parseColor("#212121"); // Темно-серый для текста

	public void show() {
		// Анимация появления индикатора и изменения фона
		ObjectAnimator.ofFloat(activeIndicator, "alpha", 0f, 1f).setDuration(200).start();
		GradientDrawable activeBg = new GradientDrawable();
		activeBg.setColor(COLOR_ACTIVE_BACKGROUND);
		activeBg.setCornerRadius(Utils.dp(context, 8)); // Закругленные углы
		contentLayout.setBackground(activeBg);
	}

	public void hide() {
		// Анимация исчезновения индикатора и возврата фона
		ObjectAnimator alphaAnimator = ObjectAnimator.ofFloat(activeIndicator, "alpha", 1f, 0f);
		alphaAnimator.setDuration(200);
		alphaAnimator.addListener(new AnimatorListenerAdapter() {
				@Override
				public void onAnimationEnd(Animator animation) {
					activeIndicator.setVisibility(View.GONE);
				}
			});
		alphaAnimator.start();

		GradientDrawable defaultBg = new GradientDrawable();
		defaultBg.setColor(COLOR_DEFAULT_BACKGROUND);
		defaultBg.setCornerRadius(Utils.dp(context, 8)); // Закругленные углы
		contentLayout.setBackground(defaultBg);
	}

	public void anim() {
		// Анимация нажатия
		ObjectAnimator clickAnimator = ObjectAnimator.ofPropertyValuesHolder(this,
																			 PropertyValuesHolder.ofFloat("scaleX", 1.0f, 0.95f, 1.0f),
																			 PropertyValuesHolder.ofFloat("scaleY", 1.0f, 0.95f, 1.0f));
		clickAnimator.setDuration(150);
		clickAnimator.start();
	}

	public PageButton(Context context, String __text, String __src) {
		super(context);
		this.context = context;

		setOrientation(LinearLayout.HORIZONTAL); // Размещение индикатора и контента горизонтально
		setGravity(Gravity.CENTER_VERTICAL); // Выравнивание по центру по вертикали
		setPadding(Utils.dp(context, 4), Utils.dp(context, 4), Utils.dp(context, 4), Utils.dp(context, 4)); // Небольшой отступ

		LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, Utils.dp(context, 60)); // Увеличил высоту
		lp.bottomMargin = Utils.dp(context, 8); // Отступ между кнопками
		setLayoutParams(lp);

		// Индикатор активной страницы
		activeIndicator = new View(context);
		{
			LayoutParams indicatorLp = new LayoutParams(Utils.dp(context, 4), LayoutParams.MATCH_PARENT); // Тонкая полоска
			indicatorLp.rightMargin = Utils.dp(context, 8); // Отступ от контента
			activeIndicator.setLayoutParams(indicatorLp);

			GradientDrawable indicatorDesign = new GradientDrawable();
			indicatorDesign.setColor(COLOR_INDICATOR);
			indicatorDesign.setCornerRadius(Utils.dp(context, 2)); // Закругленные края индикатора
			activeIndicator.setBackground(indicatorDesign);
			activeIndicator.setAlpha(0f); // Изначально прозрачный
			activeIndicator.setVisibility(View.GONE); // Изначально скрыт
		}
		addView(activeIndicator);

		// Основной контейнер для иконки и текста
		contentLayout = new LinearLayout(context);
		{
			contentLayout.setOrientation(LinearLayout.HORIZONTAL);
			contentLayout.setGravity(Gravity.CENTER_VERTICAL); // Выравнивание контента по центру
			contentLayout.setPadding(Utils.dp(context, 10), Utils.dp(context, 10), Utils.dp(context, 10), Utils.dp(context, 10));

			LayoutParams contentLp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			contentLayout.setLayoutParams(contentLp);

			GradientDrawable defaultBg = new GradientDrawable();
			defaultBg.setColor(COLOR_DEFAULT_BACKGROUND);
			defaultBg.setCornerRadius(Utils.dp(context, 8)); // Закругленные углы
			contentLayout.setBackground(defaultBg);

			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
				contentLayout.setElevation(Utils.dp(context, 2)); // Небольшая тень
			}
		}
		addView(contentLayout);

		_pagesrc = new ImageView(context);
		{
			LayoutParams imgLp = new LayoutParams(Utils.dp(context, 32), Utils.dp(context, 32)); // Размер иконки
			imgLp.rightMargin = Utils.dp(context, 10); // Отступ от текста
			_pagesrc.setLayoutParams(imgLp);
			Utils.SetAssets(context, _pagesrc, __src); // Установка иконки
		}
		contentLayout.addView(_pagesrc);

		_pagetitle = new TextView(context);
		{
			_pagetitle.setText(__text);
			_pagetitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f); // Размер текста
			_pagetitle.setTypeface(Utils.font(context));
			_pagetitle.setTextColor(COLOR_TEXT); // Цвет текста
			_pagetitle.setSingleLine(true); // Одна строка
			_pagetitle.setEllipsize(android.text.TextUtils.TruncateAt.END); // Многоточие, если текст не помещается
		}
		contentLayout.addView(_pagetitle);

		this.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					anim(); // Анимация нажатия
					if (callback != null) callback.onClick();
				}
			});
	}
}


