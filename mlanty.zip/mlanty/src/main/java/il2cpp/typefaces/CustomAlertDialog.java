package il2cpp.typefaces;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import il2cpp.Utils;
import android.graphics.drawable.ColorDrawable;

public class CustomAlertDialog extends Dialog {

    private final Context context;
    private static final String TELEGRAM_LINK = "https://t.me/DESFLEKSWARE";

    public CustomAlertDialog(Context context) {
        super(context);
        this.context = context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(createDialogView());
        setCancelable(false);
        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
    }

    private View createDialogView() {
        LinearLayout mainLayout = new LinearLayout(context);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setGravity(Gravity.CENTER);
        mainLayout.setPadding(Utils.dp(context, 20), Utils.dp(context, 20), Utils.dp(context, 20), Utils.dp(context, 20));

        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.parseColor("#FFFFFF"));
        background.setCornerRadius(Utils.dp(context, 15));
        mainLayout.setBackground(background);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mainLayout.setElevation(Utils.dp(context, 10));
        }

        TextView messageText = new TextView(context);
        messageText.setText("Вы используете бесплатную модификацию");
        messageText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        messageText.setTextColor(Color.parseColor("#212121"));
        messageText.setTypeface(Utils.font(context));
        messageText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        messageLp.bottomMargin = Utils.dp(context, 20);
        messageText.setLayoutParams(messageLp);
        mainLayout.addView(messageText);

        Button subscribeButton = new Button(context);
        subscribeButton.setText("Подписаться");
        subscribeButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        subscribeButton.setTextColor(Color.WHITE);

        GradientDrawable buttonBackground = new GradientDrawable();
        buttonBackground.setColor(Color.parseColor("#4285F4"));
        buttonBackground.setCornerRadius(Utils.dp(context, 10));
        subscribeButton.setBackground(buttonBackground);

        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(
			Utils.dp(context, 180), Utils.dp(context, 50));
        subscribeButton.setLayoutParams(buttonLp);

        subscribeButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_LINK));
					context.startActivity(browserIntent);
					dismiss();
				}
			});
        mainLayout.addView(subscribeButton);

        return mainLayout;
    }
}


